"""
Nuclear Helper

This package contains helper functions for the nuclear physics simulations.
"""

__version__ = "0.1.0"
__author__ = 'Marek Matas'
__credits__ = 'Czech Technical University in Prague'